import time
from bs4 import BeautifulSoup

from project.utils.token import generate_token
from project.models import edit_form, event
from project import get_wks_columns, wks, get_wks_records, sh
from tests.testingHelpers import clear_members_sheet, get_event_info, clear_event_sheet


def test_2_email_prim_unsub_sec_sub(client):
    """
    test_2_email_prim_sub_sec_sub tests for when a user submits the form with 2 emails. The primary
    email is unsubscribed and the secondary email is subscribed. The google sheet should have both
    fields as TRUE under the respective subscribe columns. The template right after should also
    show subscribe for the both contacts.
    """

    clear_members_sheet(wks)

    event_name, ticket, questions, base_answer = get_event_info(client)

    event_wks = clear_event_sheet(sh, event_name)

    csrf_token = ""

    email: str = "lol@lol.com"
    sec_email: str = "lol2@lol2.com"

    token = generate_token(email)

    # get CSRF token for form
    with client as c:
        response = c.get(f"/membership/full-registration/{token}")
        soup = BeautifulSoup(response.data, "html.parser")
        csrf_token_input = soup.find("input", {"name": "csrf_token"})
        assert csrf_token_input, "CSRF token not found in the form."
        csrf_token = csrf_token_input["value"]

    form_data = {
        "first_name": "AVASH_TEST",
        "last_name": "ADHIKARI_TEST",
        "primary_email": email,
        "confirm_primary": email,
        "secondary_email": sec_email,
        "confirm_secondary": sec_email,
        "secondary_subscribe": 1,
        "country_code": "",
        "register_event": "y",
        "csrf_token": csrf_token,
    }

    # add info fields to form data
    with client.application.app_context():
        required_fields = edit_form.query.filter_by(required=True).all()
        for field in required_fields:
            # Provide dummy data for dynamically generated required fields.
            if field.field_type == "Checkbox":
                # For checkboxes, WTForms expects a list of values.
                # We'll just select the first option by its index '0'.
                form_data[field.label] = "0"
            elif field.field_type == "Radio":
                # For radio buttons, we provide the value of the choice.
                options = field.options.split("\n")
                if options:
                    form_data[field.label] = options[0]
            else:  # For StringField, TextAreaField, etc.
                form_data[field.label] = f"Test data for {field.label}"

    event_name = ""
    # add event fields to form data
    with client.application.app_context():
        event_obj = event.query.filter_by(live=True).order_by(event.id.desc()).first()
        event_name = event_obj.name
        ticket_types = event_obj.tickets.split("\n")
        form_data["event_tickets"] = ticket_types[0]

        for question in event_obj.questions.split("\n"):
            form_data["event_" + question] = "test answer from test_registration_happy"

    # Send POST form data
    with client as c:
        response = c.post(
            f"/membership/full-registration/{token}",
            data=form_data,
            follow_redirects=True,
        )

        soup = BeautifulSoup(response.data, "html.parser")

        # Check if the receipt page was rendered by looking for its heading.
        heading = soup.find("h1", string="I2G Membership Completed")
        input = soup.find("input", {"name": "first_name"})
        assert not input, "The form has been rerendered"
        assert heading is not None, (
            "The receipt page was not rendered. The registration may have failed."
        )

        # Check that both emails show as subscribed in the rendered receipt
        # Find all paragraphs containing email information
        paragraphs = soup.find_all("p")

        # Check for primary email subscription status
        primary_email_found = False
        for p in paragraphs:
            if email in p.get_text() and "Primary Email:" in p.get_text():
                primary_email_found = True
                assert "(Unsubscribed)" in p.get_text(), (
                    f"Primary email should show as Unsubscribed in receipt.\nFound: {p.get_text()}"
                )
                break
        assert primary_email_found, "Primary email paragraph not found in receipt"

        # Check for secondary email subscription status
        secondary_email_found = False
        for p in paragraphs:
            if sec_email in p.get_text() and "Secondary Email:" in p.get_text():
                secondary_email_found = True
                assert "(Subscribed)" in p.get_text(), (
                    f"Secondary email should show as Subscribed in receipt. Found: {p.get_text()}"
                )
                break
        assert secondary_email_found, "Secondary email paragraph not found in receipt"

    time.sleep(2)
    records = get_wks_records(wks)
    assert len(records) == 1, "Records has more or less then one item"
    row = records[0]

    assert row["Primary Subscribed"] == "FALSE"
    assert row["Secondary Subscribed"] == "TRUE"


def test_2_email_prim_unsub_sec_unsub(client):
    """
    test_2_email_prim_sub_sec_sub tests for when a user submits the form with 2 emails. The primary
    email is unsubscribed and the secondary email is unsubscribed. The google sheet should have both
    fields as TRUE under the respective subscribe columns. The template right after should also
    show subscribe for the both contacts.
    """

    clear_members_sheet(wks)

    event_name, ticket, questions, base_answer = get_event_info(client)

    event_wks = clear_event_sheet(sh, event_name)

    csrf_token = ""

    email: str = "lol@lol.com"
    sec_email: str = "lol2@lol2.com"

    token = generate_token(email)

    # get CSRF token for form
    with client as c:
        response = c.get(f"/membership/full-registration/{token}")
        soup = BeautifulSoup(response.data, "html.parser")
        csrf_token_input = soup.find("input", {"name": "csrf_token"})
        assert csrf_token_input, "CSRF token not found in the form."
        csrf_token = csrf_token_input["value"]

    form_data = {
        "first_name": "AVASH_TEST",
        "last_name": "ADHIKARI_TEST",
        "primary_email": email,
        "confirm_primary": email,
        "secondary_email": sec_email,
        "confirm_secondary": sec_email,
        "country_code": "",
        "register_event": "y",
        "csrf_token": csrf_token,
    }

    # add info fields to form data
    with client.application.app_context():
        required_fields = edit_form.query.filter_by(required=True).all()
        for field in required_fields:
            # Provide dummy data for dynamically generated required fields.
            if field.field_type == "Checkbox":
                # For checkboxes, WTForms expects a list of values.
                # We'll just select the first option by its index '0'.
                form_data[field.label] = "0"
            elif field.field_type == "Radio":
                # For radio buttons, we provide the value of the choice.
                options = field.options.split("\n")
                if options:
                    form_data[field.label] = options[0]
            else:  # For StringField, TextAreaField, etc.
                form_data[field.label] = f"Test data for {field.label}"

    event_name = ""
    # add event fields to form data
    with client.application.app_context():
        event_obj = event.query.filter_by(live=True).order_by(event.id.desc()).first()
        event_name = event_obj.name
        ticket_types = event_obj.tickets.split("\n")
        form_data["event_tickets"] = ticket_types[0]

        for question in event_obj.questions.split("\n"):
            form_data["event_" + question] = "test answer from test_registration_happy"

    # Send POST form data
    with client as c:
        response = c.post(
            f"/membership/full-registration/{token}",
            data=form_data,
            follow_redirects=True,
        )

        soup = BeautifulSoup(response.data, "html.parser")

        # Check if the receipt page was rendered by looking for its heading.
        heading = soup.find("h1", string="I2G Membership Completed")
        input = soup.find("input", {"name": "first_name"})
        assert not input, "The form has been rerendered"
        assert heading is not None, (
            "The receipt page was not rendered. The registration may have failed."
        )

        # Check that both emails show as subscribed in the rendered receipt
        # Find all paragraphs containing email information
        paragraphs = soup.find_all("p")

        # Check for primary email subscription status
        primary_email_found = False
        for p in paragraphs:
            if email in p.get_text() and "Primary Email:" in p.get_text():
                primary_email_found = True
                assert "(Unsubscribed)" in p.get_text(), (
                    f"Primary email should show as Unsubscribed in receipt.\nFound: {p.get_text()}"
                )
                break
        assert primary_email_found, "Primary email paragraph not found in receipt"

        # Check for secondary email subscription status
        secondary_email_found = False
        for p in paragraphs:
            if sec_email in p.get_text() and "Secondary Email:" in p.get_text():
                secondary_email_found = True
                assert "(Unsubscribed)" in p.get_text(), (
                    f"Secondary email should show as Unsubscribed in receipt. Found: {p.get_text()}"
                )
                break
        assert secondary_email_found, "Secondary email paragraph not found in receipt"

    time.sleep(2)
    records = get_wks_records(wks)
    assert len(records) == 1, "Records has more or less then one item"
    row = records[0]

    assert row["Primary Subscribed"] == "FALSE"
    assert row["Secondary Subscribed"] == "FALSE"
