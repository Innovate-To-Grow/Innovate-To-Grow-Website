import time
import re

from bs4 import BeautifulSoup

from project.utils.token import generate_token
from project.models import edit_form, event
from project import get_wks_columns, wks, get_wks_records, sh
from tests.testingHelpers import clear_members_sheet, get_event_info, clear_event_sheet

def test_2_email_1_phone_verified_subscribed_display(client):
    """
    Tests that the successfully_registered.html template correctly displays phone number
    verification and subscription status for users with 2 emails and 1 phone number.
    User should have phone number "+18057105809" with "TRUE" for both verified and subscribed.
    """

    clear_members_sheet(wks)

    event_name, ticket, questions, base_answer = get_event_info(client)

    event_wks = clear_event_sheet(sh, event_name)

    wks_columns = get_wks_columns(wks)
    user = ["" for i in range(len(wks_columns))]
    primary_email = "test@email.com"
    secondary_email = "test2@email.com"
    phone_number = "+18057105809"
    first_name = "TEST FIRST NAME"
    last_name = "TEST LAST NAME"

    user[wks_columns["Order"] - 1] = "1"
    user[wks_columns["First Name"] - 1] = first_name
    user[wks_columns["Last Name"] - 1] = last_name
    user[wks_columns["When Started"] - 1] = "TEST START"
    user[wks_columns["Last Updated"] - 1] = "TEST UPDATE"
    user[wks_columns["Primary Email"] - 1] = primary_email
    user[wks_columns["Primary Verified"] - 1] = "TRUE"
    user[wks_columns["Primary Subscribed"] - 1] = "TRUE"
    user[wks_columns["Primary Expired"] - 1] = "FALSE"
    user[wks_columns["Primary Bounced"] - 1] = ""
    user[wks_columns["Secondary Email"] - 1] = secondary_email
    user[wks_columns["Secondary Verified"] - 1] = "TRUE"
    user[wks_columns["Secondary Subscribed"] - 1] = "TRUE"
    user[wks_columns["Secondary Expired"] - 1] = "FALSE"
    user[wks_columns["Secondary Bounced"] - 1] = ""
    user[wks_columns["Info Completed"] - 1] = "TRUE"
    user[wks_columns["Phone Number"] - 1] = phone_number
    user[wks_columns["Phone number subscribed"] - 1] = "TRUE"
    user[wks_columns["Phone number verified"] - 1] = "TRUE"  # Phone already verified

    wks.append_row(user)
    time.sleep(3)

    token = generate_token(primary_email)

    with client as c:
        response = c.get(f"membership/event-registration/{event_name}/{token}")
        soup = BeautifulSoup(response.data, "html.parser")
        csrf_token_input = soup.find("input", {"name": "csrf_token"})
        assert csrf_token_input, "CSRF token not found in the form."
        csrf_token = csrf_token_input["value"]  # type: ignore

    form_data = {
        "first_name": first_name,
        "last_name": last_name,
        "primary_email": primary_email,
        "confirm_primary": primary_email,
        "secondary_email": secondary_email,
        "confirm_secondary": secondary_email,
        "phone_number": "8057105809",  # Same phone number as in database
        "confirm_phone_number": "8057105809",
        "country_code": "+1",
        "phone_subscribe": "y",
        "primary_subscribe": "y",
        "secondary_subscribe": "y",
        "register_event": "y",
        "csrf_token": csrf_token,
    }

    with client.application.app_context():
        required_fields = edit_form.query.filter_by(required=True).all()
        for field in required_fields:
            if field.field_type == "Checkbox":
                form_data[field.label] = "0"
            elif field.field_type == "Radio":
                options = field.options.split("\n")
                if options:
                    form_data[field.label] = options[0]
            else:  # For StringField, TextAreaField, etc.
                form_data[field.label] = f"Test data for {field.label}"

    form_data["event_tickets"] = ticket
    counter = 1
    for question in questions:
        form_data["event_" + question] = base_answer + str(counter)
        counter += 1

    with client as c:
        response = c.post(
            f"membership/event-registration/{event_name}/{token}",
            data=form_data,
            follow_redirects=True,
        )

        soup = BeautifulSoup(response.data, "html.parser")

        success_heading = soup.find(
            "p", string=f"You have successfully registered for {event_name} "
        )
        assert success_heading is not None, "Success page was not rendered"

        phone_verified_text = soup.find(
            "p",
            string=lambda text: text
            and "Phone Number:" in text
            and "(Verified)" in text,
        )
        phone_subscribed_text = soup.find(
            "p",
            string=lambda text: text
            and "Phone Number:" in text
            and "(Subscribed)" in text,
        )

        assert phone_verified_text is not None, (
            "Phone should show as verified in success page"
        )
        assert phone_subscribed_text is not None, (
            "Phone should show as subscribed in success page"
        )

        phone_p_tag = soup.find(
            "p", string=lambda text: text and "Phone Number:" in text
        )
        assert phone_p_tag is not None, "Phone number paragraph not found"
        phone_text = phone_p_tag.get_text()
        assert "(Verified)" in phone_text, (
            "Phone verification status not displayed correctly"
        )
        assert "(Subscribed)" in phone_text, (
            "Phone subscription status not displayed correctly"
        )

        primary_email_text = soup.find(
            "p",
            string=lambda text: text
            and "Primary Email:" in text
            and primary_email in text,
        )
        secondary_email_text = soup.find(
            "p",
            string=lambda text: text
            and "Secondary Email:" in text
            and secondary_email in text,
        )

        assert primary_email_text is not None, "Primary email not found in success page"
        assert secondary_email_text is not None, (
            "Secondary email not found in success page"
        )

        time.sleep(2)
        records = get_wks_records(wks)
        row = records[0]
        assert row["Primary Email"] == primary_email, (
            "primary email changed in members sheet when it should stay the same"
        )
        assert row["Secondary Email"] == secondary_email, (
            "secondary email changed in members sheet when it should stay the same"
        )
        assert row["Phone Number"] == int(phone_number[1:]), (
            "phone number not updated in members sheet"
        )
        assert row["Phone number verified"] == "TRUE", (
            "phone number verification should remain TRUE"
        )
        assert row["Phone number subscribed"] == "TRUE", (
            "phone number subscription should remain TRUE"
        )
