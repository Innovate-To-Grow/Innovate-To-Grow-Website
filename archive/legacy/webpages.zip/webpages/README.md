# Innovate To Grow — Membership & Event Management

Web application for managing memberships, event registrations, and email/SMS communications
for the Innovate To Grow program at UC Merced.

## Tech Stack

- **Backend:** Python 3, Flask, Jinja2 templates
- **Database:** SQLite (via SQLAlchemy + Flask-SQLAlchemy)
- **Admin:** Flask-Admin with Flask-Login authentication
- **Data:** Google Sheets API (gspread) for membership records
- **Email:** Gmail IMAP for receiving
- **Rate Limiting:** Flask-Limiter
- **Caching:** Flask-Caching
- **WSGI:** Waitress

## Prerequisites

- Python 3.9+
- Google Cloud service account with Sheets API access
- Gmail account with app password (for IMAP)

## Setup

```bash
# Clone the repository
git clone <repo-url>
cd Innovate-To-Grow-Website-Old

# Create and activate a virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your real credentials (see Configuration below)

# Place your Google service account key in the project root
# (expected at ./service_account.json — this file is gitignored)
```

## Configuration

All secrets are read from environment variables (via `.env`). See `.env.example` for the full template.

| Variable | Description |
|---|---|
| `CURRENT_SPREADSHEET` | Google Sheet name for membership data |
| `MAIL_USERNAME` | Gmail address for IMAP/SMTP |
| `MAIL_PASSWORD` | Gmail app password |
| `SECRET_KEY` | Flask session secret (generate with `secrets.token_urlsafe(32)`) |
| `SECURITY_PASSWORD_SALT` | Password hashing salt |
| `DEFAULT_ADMIN_EMAIL` | Admin email for first-time DB creation |
| `DEFAULT_ADMIN_PASSWORD` | Admin password for first-time DB creation |

## Running

```bash
# Development (debug mode, Werkzeug server on port 5001)
python app.py

# Production (Waitress, 8 threads)
# Set DEBUG=False in your environment, then:
python app.py
```

## Project Structure

```
.
├── app.py                  # Application entry point
├── config/
│   └── default.py          # Configuration (reads from env vars)
├── project/
│   ├── __init__.py         # App factory, DB init, Google Sheets setup
│   ├── models.py           # SQLAlchemy models
│   ├── forms/              # WTForms definitions
│   ├── views/              # Blueprint route handlers
│   │   ├── home.py         # Main site pages
│   │   ├── registration.py # Membership registration flow
│   │   ├── update.py       # Membership info update flow
│   │   ├── events.py       # Event registration flow
│   │   ├── confirm.py      # Email confirmation
│   │   ├── geo.py          # Geo-location features
│   │   └── admin.py        # Flask-Admin custom views
│   ├── utils/              # Utility modules
│   ├── services/           # Logging service
│   ├── static/             # CSS, JS, images, fonts
│   └── templates/          # Jinja2 templates
├── tests/
│   ├── conftest.py         # Pytest fixtures
│   ├── testingHelpers.py   # Test utilities
│   ├── legacy/             # Integration tests
│   └── logic/              # Unit tests
└── requirements.txt
```

## Testing

```bash
# Run all tests
pytest tests/ -v

# Run legacy integration tests only
pytest tests/legacy/ -v

# Run unit tests only
pytest tests/logic/ -v
```

Tests are configured in `tests/conftest.py` to use the "Test I2G Membership"
spreadsheet — ensure your `.env` is set accordingly before running tests.

## License

See [LICENSE](LICENSE).
