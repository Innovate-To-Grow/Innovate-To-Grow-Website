"""
Email Confirmation View

Handles email verification via confirmation tokens.
"""

import asyncio
import time
from datetime import datetime

from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from project import app, get_wks_columns, get_wks_records, tz, wks
from project.forms.otp_forms import OTPForm
from project.utils.utils import query_primary_column
from gspread.cell import Cell

confirm_blueprint = Blueprint("confirm",
                              __name__,
                              template_folder="../templates/membership/events",
                              url_prefix=app.config["URL_PREFIX"])


@confirm_blueprint.route("/otp", methods=["GET", "POST"])
def otp():
    """
    Handle OTP verification for phone numbers.

    Since Twilio has been removed, OTP verification is no longer available.
    Users who reach this page are redirected home with a message.
    """
    flash("Phone verification is currently unavailable. Please contact support.", "warning")
    return redirect(url_for("home.mainpage"))
