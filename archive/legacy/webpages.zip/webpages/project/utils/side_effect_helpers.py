"""
Side Effect Helper Functions

This module contains functions that handle all the side effects for event registration
and user updates. These functions are separated from the pure business logic to enable
better testing, maintainability, and reusability.

Functions in this module:
- Execute database/worksheet updates
- Send emails (verification, confirmation, notification)
- Start background timers
- Handle Flask context operations
"""

import logging
import time
from datetime import datetime
from threading import Thread
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

from flask import url_for, render_template, copy_current_request_context
from gspread.cell import Cell

from project import app, sh, wks, tz, get_wks_records, get_wks_columns
from project.utils.email import send_email
from project.utils.token import generate_token


def execute_cell_updates(
        cell_updates: List[Dict[str, Any]], worksheet_name: str = "membership"
) -> None:
    """
    Execute a batch of cell updates on a specified worksheet.

    Args:
        cell_updates: List of dicts with keys: row, column, value
        worksheet_name: Name of worksheet to update ("membership" or event name)
    """
    if not cell_updates:
        return

    # Get the appropriate worksheet
    if worksheet_name == "membership":
        worksheet = wks
        columns = get_wks_columns(wks)
    else:
        worksheet = sh.worksheet(worksheet_name)
        columns = get_wks_columns(worksheet)

    # Convert to Cell objects
    cells = []
    for update in cell_updates:
        cell = Cell(
            row=update["row"], col=columns[update["column"]], value=update["value"]
        )
        cells.append(cell)

    # Execute batch update
    if cells:
        worksheet.update_cells(cells)


def send_verification_email(
        email: str,
        user_first_name: str,
        user_last_name: str,
        start_expiry_timer: bool = True,
) -> None:
    """
    Send a verification email to the specified address.

    Args:
        email: Email address to send verification to
        user_first_name: User's first name for personalization
        user_last_name: User's last name for personalization
        start_expiry_timer: Whether to start the expiry timer for this email
    """
    token = generate_token(email)
    confirm_url = url_for("registration.confirm", token=token, _external=True)

    html = render_template(
        "verify_email.html",
        first=user_first_name,
        last=user_last_name,
        confirm_url=confirm_url,
    )

    send_email(email, app.config["VERIF_SUBJECT"], html)

    if start_expiry_timer:
        start_email_expiry_timer(email)


def send_confirmation_email(
        email: str, subject: str, template_name: str, template_data: Dict[str, Any]
) -> None:
    """
    Send a confirmation/receipt email using specified template.

    Args:
        email: Recipient email address
        subject: Email subject line
        template_name: Name of the template to render
        template_data: Data to pass to the template
    """
    html = render_template(template_name, **template_data)
    send_email(email, subject, html)


def send_deletion_notice_email(
        email: str, user_first_name: str, user_last_name: str, deleted_email: str
) -> None:
    """
    Send notification that an email address has been removed from their account.

    Args:
        email: Email to send notification to (their other verified email)
        user_first_name: User's first name
        user_last_name: User's last name
        deleted_email: The email address that was removed
    """
    html = render_template(
        "deleting_email.html",
        first=user_first_name,
        last=user_last_name,
        email=deleted_email,
    )
    send_email(email, app.config["REMOVE_SUBJECT"], html)


def start_email_expiry_timer(email: str) -> None:
    """
    Start a background timer to mark email as expired if not verified.

    Args:
        email: Email address to set expiry timer for
    """

    @copy_current_request_context
    def expiry_timer():
        time.sleep(app.config["EXPIRY_TIMER"])

        # Re-fetch current data to check verification status
        wks_records = get_wks_records(wks)
        wks_columns = get_wks_columns(wks)

        # Find user with this email (could be primary or secondary)
        user_row = None
        email_type = None

        for row in wks_records:
            if row["Primary Email"] == email:
                user_row = row
                email_type = "Primary"
                break
            elif row["Secondary Email"] == email:
                user_row = row
                email_type = "Secondary"
                break

        if user_row and user_row[f"{email_type} Verified"] == "FALSE":
            # Email is still unverified, mark as expired
            wks.update_cell(
                user_row["Row"], wks_columns[f"{email_type} Expired"], "TRUE"
            )

    thread = Thread(target=expiry_timer)
    thread.start()


def refresh_user_data(
        primary_email: str, secondary_email: str
) -> Optional[Dict[str, Any]]:
    """
    Re-fetch user data from worksheet after updates.

    Args:
        primary_email: User's primary email
        secondary_email: User's secondary email

    Returns:
        Updated user record or None if not found
    """
    wks_records = get_wks_records(wks)

    # Find user by email combination
    for row in wks_records:
        if (
                row["Primary Email"] == primary_email
                and row["Secondary Email"] == secondary_email
        ):
            return row

    return None


def create_event_registration(
        event_worksheet_name: str, user_data: Dict[str, Any], event_data: Dict[str, Any]
) -> None:
    """
    Create a new event registration row in the event worksheet.

    Args:
        event_worksheet_name: Name of the event worksheet
        user_data: User information (name, emails, etc.)
        event_data: Event-specific data (ticket type, answers, etc.)
    """
    event_wks = sh.worksheet(event_worksheet_name)
    event_wks_columns = get_wks_columns(event_wks)

    # Create new row with all required data
    row = ["" for i in range(len(event_wks.row_values(1)))]

    # Generate order number
    last_order = event_wks.col_values(1)[-1] if event_wks.col_values(1) else "0"
    order = int(last_order) + 1 if last_order.isdigit() else 1

    # Set basic fields
    current_time = (
        datetime.now(tz).replace(second=0, microsecond=0).strftime("%Y-%m-%d %I:%M %p")
    )

    row[event_wks_columns["Order"] - 1] = order
    row[event_wks_columns["First Name"] - 1] = user_data["first_name"]
    row[event_wks_columns["Last Name"] - 1] = user_data["last_name"]
    row[event_wks_columns["When Started"] - 1] = current_time
    row[event_wks_columns["Last Updated"] - 1] = current_time
    row[event_wks_columns["Membership Primary"] - 1] = user_data["primary_email"]
    row[event_wks_columns["Membership Secondary"] - 1] = user_data["secondary_email"]

    # Set event-specific fields
    for field_name, value in event_data.items():
        if field_name in event_wks_columns:
            row[event_wks_columns[field_name] - 1] = value

    # Append the new row
    event_wks.append_row(row)


def update_subscription_status(
        user_row: int,
        primary_subscription: Optional[bool],
        secondary_subscription: Optional[bool],
        primary_verified: bool,
        secondary_verified: bool,
        secondary_email: str = None,
) -> None:
    """
    Update subscription status based on verification status and user preferences.

    Args:
        user_row: Row number of the user
        primary_subscription: User's primary email subscription preference (None = keep existing)
        secondary_subscription: User's secondary email subscription preference (None = keep existing)
        primary_verified: Whether primary email is verified
        secondary_verified: Whether secondary email is verified
        secondary_email: Current secondary email (to check if it was cleared)
    """
    wks_columns = get_wks_columns(wks)
    cells = []

    # Primary subscription logic
    if primary_verified and primary_subscription is not None:
        # User preference applies only if email is verified
        cells.append(
            Cell(
                user_row,
                wks_columns["Primary Subscribed"],
                str(primary_subscription).upper(),
            )
        )
    elif not primary_verified:
        # Unverified emails cannot be subscribed
        cells.append(Cell(user_row, wks_columns["Primary Subscribed"], "FALSE"))

    # Secondary subscription logic
    # Only update secondary subscription if secondary email exists
    if secondary_email:  # Only process if secondary email is not empty
        if secondary_verified and secondary_subscription is not None:
            # User preference applies only if email is verified
            cells.append(
                Cell(
                    user_row,
                    wks_columns["Secondary Subscribed"],
                    str(secondary_subscription).upper(),
                )
            )
        elif not secondary_verified:
            # Unverified emails cannot be subscribed
            cells.append(Cell(user_row, wks_columns["Secondary Subscribed"], "FALSE"))

    # Apply updates
    if cells:
        wks.update_cells(cells)


def update_completion_status(user_row: int) -> None:
    """
    Mark user registration as completed and update timestamp.

    Args:
        user_row: Row number of the user
    """
    wks_columns = get_wks_columns(wks)
    current_time = (
        datetime.now(tz).replace(second=0, microsecond=0).strftime("%Y-%m-%d %I:%M %p")
    )

    cells = [
        Cell(user_row, wks_columns["Last Updated"], current_time),
        Cell(user_row, wks_columns["Info Completed"], "TRUE"),
    ]

    wks.update_cells(cells)


def send_event_confirmation_emails(
        user: Dict[str, Any],
        event_name: str,
        event_url: str,
        update_url: str,
        info_fields: Dict[str, Any],
        event_fields: Dict[str, Any],
) -> None:
    """
    Send event registration confirmation emails to verified addresses.

    Args:
        user: User data with verification status
        event_name: Name of the event
        event_url: URL to event registration
        update_url: URL to update registration
        info_fields: User's profile information
        event_fields: Event-specific registration data
    """
    subject = f"{event_name} Registration Completed"

    # Format phone number with + prefix for display
    phone_num = user.get("Phone Number", "")
    if phone_num:
        phone_num_str = str(phone_num)
        phone_display = (
            f"+{phone_num_str}" if not phone_num_str.startswith("+") else phone_num_str
        )
    else:
        phone_display = ""

    template_data = {
        "event_url": event_url,
        "update_url": update_url,
        "first": user["First Name"],
        "last": user["Last Name"],
        "primary_email": user["Primary Email"],
        "primary_verified": user["Primary Verified"],
        "primary_subscribed": user["Primary Subscribed"],
        "secondary_email": user["Secondary Email"],
        "secondary_verified": user["Secondary Verified"],
        "secondary_subscribed": user["Secondary Subscribed"],
        "phone_number": phone_display,
        "phone_number_verified": user.get("Phone number verified", "FALSE"),
        "phone_subscribed": user.get("Phone number subscribed", "FALSE"),
        "info_fields": info_fields,
        "event_name": event_name,
        "event_fields": event_fields,
    }

    # Send to verified emails only
    if user["Primary Verified"] == "TRUE" and user["Primary Email"]:
        send_confirmation_email(
            user["Primary Email"], subject, "event_receipt_email.html", template_data
        )

    if user["Secondary Verified"] == "TRUE" and user["Secondary Email"]:
        send_confirmation_email(
            user["Secondary Email"], subject, "event_receipt_email.html", template_data
        )


def create_complete_user_registration(
        user_data: Dict[str, Any], custom_fields: List[Dict[str, Any]] = None
) -> int:
    """
    Create a new user record for complete registration and return the row number.

    This function creates a complete user registration where:
    - Primary email is immediately verified and subscribed
    - Secondary email is unverified and unsubscribed
    - Info is marked as completed immediately
    - All custom fields are populated from user_data

    Args:
        user_data: Dictionary with all user data mapped to column names
        custom_fields: List of custom field definitions (optional, for validation)

    Returns:
        int: Row number of the created user record
    """
    wks_columns = get_wks_columns(wks)

    # Create new row array with correct length
    user_row = ["" for _ in range(len(wks.row_values(1)))]

    # Map user_data to correct column positions
    for column_name, value in user_data.items():
        if column_name in wks_columns:
            user_row[wks_columns[column_name] - 1] = value

    # Append the new user row
    wks.append_row(user_row)

    # Get the row number of the newly created user
    # The new row will be at the end, so get current row count
    new_row_number = len(wks.get_all_values())

    return new_row_number


def send_complete_registration_confirmation_email(
        primary_email: str,
        user_data: Dict[str, Any],
        info_fields: Dict[str, Any],
        event_fields: Dict[str, Any],
        event_url: Optional[str],
        update_url: str,
        event_name: Optional[str] = None,
) -> None:
    """
    Send confirmation email for complete registration.

    This function sends the confirmation email specifically for complete registration,
    which includes both membership and optional event registration information.

    Args:
        primary_email: Email address to send confirmation to (primary email)
        user_data: Complete user data including verification status
        info_fields: User's profile information fields
        event_fields: Event-specific registration data (if applicable)
        event_url: URL to event registration page (if applicable)
        update_url: URL to update user information
        event_name: Name of the event (if applicable)
    """
    subject = "I2G Membership Completed"

    template_data = {
        "event_url": event_url,
        "update_url": update_url,
        "first": user_data.get("First Name", ""),
        "last": user_data.get("Last Name", ""),
        "primary_email": user_data.get("Primary Email", ""),
        "primary_verified": user_data.get("Primary Verified", "FALSE"),
        "primary_subscribed": user_data.get("Primary Subscribed", "FALSE"),
        "secondary_email": user_data.get("Secondary Email", ""),
        "secondary_verified": user_data.get("Secondary Verified", "FALSE"),
        "secondary_subscribed": user_data.get("Secondary Subscribed", "FALSE"),
        "phone_number": str(user_data.get("Phone Number", "")),
        "phone_number_verified": user_data.get("Phone number verified", "FALSE"),
        "phone_subscribed": user_data.get("Phone number subscribed", "FALSE"),
        "info_fields": info_fields,
        "event_name": event_name,
        "event_fields": event_fields,
    }

    # Send confirmation email using the complete registration template
    send_confirmation_email(
        primary_email, subject, "info_receipt_email.html", template_data
    )



def extract_phone_data_from_event_form(form) -> Dict[str, Any]:
    """
    Extract and structure phone data from event registration form.

    This is a side effect function that safely extracts phone data from
    the event form object and formats it for processing.

    Args:
        form: Event registration form object

    Returns:
        Dict with structured phone data
    """
    try:
        country_code = (
            getattr(form, "country_code", None).data
            if hasattr(form, "country_code")
            else ""
        )
        phone_number = (
            getattr(form, "phone_number", None).data
            if hasattr(form, "phone_number")
            else ""
        )
        phone_subscribe = (
            getattr(form, "phone_subscribe", None).data
            if hasattr(form, "phone_subscribe")
            else False
        )

        # Clean and format the data
        country_code = country_code.strip() if country_code else ""
        phone_number = phone_number.strip() if phone_number else ""

        full_phone = (
            country_code + phone_number if country_code and phone_number else ""
        )

        return {
            "country_code": country_code,
            "phone_number": phone_number,
            "phone_subscribe": phone_subscribe,
            "full_phone_number": full_phone,
        }
    except Exception as e:
        # Log error and return safe defaults
        logger.error("Error extracting phone data from form: %s", e, exc_info=True)
        return {
            "country_code": "",
            "phone_number": "",
            "phone_subscribe": False,
            "full_phone_number": "",
        }


def create_event_registration_with_phone(
        event_worksheet_name: str,
        user_data: dict[str, Any],
        event_data: dict[str, Any],
        phone_data: Optional[dict[str, Any]] = None,
) -> None:
    """
    Create a new event registration row with phone information.

    Enhanced version of create_event_registration that includes phone data.

    Args:
        event_worksheet_name: Name of the event worksheet
        user_data: User information (name, emails, etc.)
        event_data: Event-specific data (ticket type, answers, etc.)
        phone_data: Phone-related data (optional)
    """
    try:
        event_wks = sh.worksheet(event_worksheet_name)
        event_wks_columns = get_wks_columns(event_wks)

        # Create new row with all required data
        row = ["" for i in range(len(event_wks.row_values(1)))]

        # Generate order number
        last_order = event_wks.col_values(1)[-1] if event_wks.col_values(1) else "0"
        order = int(last_order) + 1 if last_order.isdigit() else 1

        # Set basic fields
        current_time = (
            datetime.now(tz)
            .replace(second=0, microsecond=0)
            .strftime("%Y-%m-%d %I:%M %p")
        )

        row[event_wks_columns["Order"] - 1] = order
        row[event_wks_columns["First Name"] - 1] = user_data["first_name"]
        row[event_wks_columns["Last Name"] - 1] = user_data["last_name"]
        row[event_wks_columns["When Started"] - 1] = current_time
        row[event_wks_columns["Last Updated"] - 1] = current_time
        row[event_wks_columns["Membership Primary"] - 1] = user_data["primary_email"]
        row[event_wks_columns["Membership Secondary"] - 1] = user_data[
            "secondary_email"
        ]

        # Add phone data if provided and column exists
        if phone_data and "Phone Number" in event_wks_columns:
            row[event_wks_columns["Phone Number"] - 1] = phone_data.get(
                "full_phone_number", ""
            )

        # Set event-specific fields
        for field_name, value in event_data.items():
            if field_name in event_wks_columns:
                row[event_wks_columns[field_name] - 1] = value

        # Append the new row
        event_wks.append_row(row)
    except Exception as e:
        import traceback

        traceback.print_exc()
