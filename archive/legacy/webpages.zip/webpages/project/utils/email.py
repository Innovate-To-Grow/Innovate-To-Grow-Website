import logging

logger = logging.getLogger(__name__)


def send_email(recipient, subject, template):
    """No-op: AWS SES has been removed. Logs what would have been sent."""
    logger.info(
        "Email not sent (SES removed) — to=%s subject=%s", recipient, subject
    )
